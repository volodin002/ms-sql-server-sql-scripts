
EXEC sp_spaceused N'Cp.Account';